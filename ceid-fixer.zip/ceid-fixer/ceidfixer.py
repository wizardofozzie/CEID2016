from io import BytesIO

import re

RE_STYLEURL = re.compile("<styleUrl>#\w+</styleUrl>")
RE_STYLEURL_EXPOSED = re.compile("<styleUrl>#\w+[^un]{2}exposed.+</styleUrl>")    #contain exposed but not unexposed
RE_KLASS = re.compile("<name>\([0-5]\) .+</name>")


try:    import xml.etree.cElementTree as ET
except: import xml.etree.ElementTree as ET


def get_fldr_vars(kfldr):
    """Parse structure FOLDER for:
        name,
        exposed or unexposed,
        class number (0-5)
    """
    namefield = kfldr.name                          # TODO: pseudocode-ish
    # extract class ranking from top-level FLDR>Name field
    klass = get_class_val(namefield)
    # find FLDR>Placemark which is for our icon
    for pm in kfldr.placemarks:
        if str(get_placemark_type(pm)) == 'icon':
            exposed = get_exposed_val(pm.stylesheet)
            name = pm.name
    return dict(name=name, exposed=exposed, klass=klass)



def get_class_val(namestr):
    """Get structure's class (ranking) from FOLDER's name value"""
    d = {
        0: '0or1',
        1: '0or1',
        2: '2',
        3: '3',
        4: '4or5',
        5: '4or5',
    }
    assert RE_KLASS.match(namestr) is not None
    srch = RE_KLASS.search(namestr)
    SLICE = slice(srch.start()+len("<name>("), srch.start()+len("<name>(")+1)
    return d[int(namestr[SLICE])]


def get_exposed_val(stylestr):
    """Retrieve structure's exposed status from icon placemark styleUrl"""
    if "exposed" not in stylestr:
        raise Exception("Weird incoming naming convention")
    return "exposed" if RE_STYLEURL_EXPOSED.match(stylestr) else "unexposed"


def get_placemark_type(pm):
    """Determine whether fastkml Placemark object is for KML icon or polygon"""
    # check whether placemark.geometry type is Point
    # if hasattr(pm, "description") and len(pm.description) > 0:
    if hasattr(pm, 'geometry') and str(pm.geometry).startswith('POINT'):
        return "icon"
    # ccheck whether placemark.geometry type is Point
    elif hasattr(pm, 'geometry') and str(pm.geometry).startswith('LINESTRING'):
        return "polygon"
    else:
        raise Exception("unknown placemark type!")


def create_styleurl(stylestr):
    """Rename placemarks' styleUrl to new styleUrl names"""
    klass = get_class_val(stylestr)
    if get_placemark_type(stylestr) == "icon":
        exposed = get_exposed_val(stylestr)
        return "#style_pm_{}_class{}".format(exposed, klass)
    elif get_placemark_type(stylestr) == "polygon":
        return "#class{}".format(klass)
    else:
        return "#ERROR_CHECKME"


def replace_styleurls(kfldr):
    """Rename FLDR>Placemark>styleUrl fields (where kfldr is kml folder object)
    kfldr is fastkml folder object"""
    # TODO: pseudocode!
    # iterate through kfldr's placemarks
    for pm in kfldr.placemarks:
        if get_placemark_type(pm) == 'icon':
            newstyle_str = create_styleurl(pm.styleUrl)
            pm.styleUrl = newstyle_str
        elif get_placemark_type(pm) == 'polygon':
            newstyle_str = create_styleurl(pm.styleUrl)
            pm.styleUrl = newstyle_str

# fastkml functions


def get_structures(fldr):
    """Get structure objects from L2 Continent folder object"""
    assert type(fldr) in ('fastkml.kml.Folder', 'kml.Folder')
    subfldrs = [list(x.features()) for x in [fldr]]

def get_structure_features(struct):
    assert type(struct) in ('fastkml.kml.Folder', 'kml.Folder')
    return list(struct.features())
