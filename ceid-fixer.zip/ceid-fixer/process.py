from fastkml import kml
from ceidfixer import *

import os, sys

docfile = os.path.join(os.path.split(__file__)[0], "doc.kml")

with open(docfile, 'r') as fo:
    doc = fo.read()

k = kml.KML()
k.from_string(doc)

features = list(k.features())
f2 = fldr_root = \
    list(features[0].features())   # ceid root folder
f3 = fldr_continents = \
    list(f2[0].features())        # continent folders

# setup list of structure folders for each continent [structure1, structure2...]
fldr_australia, fldr_africa, fldr_antarctica, \
fldr_asia, fldr_europe, fldr_namerica, fldr_samerica = \
    [list(x.features()) for x in fldr_continents]


# eg
# Acraman
acraman = fldr_australia[1]
placemarks = list(acraman.features())
pm1, pm2 = placemarks

# placemark functions
# pm1.address       pm1.description   pm1.from_element  pm1.isopen        pm1.phoneNumber   pm1.targetId
# pm1.append_style  pm1.end           pm1.from_string   pm1.link          pm1.snippet       pm1.timeStamp
# pm1.author        pm1.etree_element pm1.geometry      pm1.name          pm1.styleUrl      pm1.to_string
# pm1.begin         pm1.extended_data pm1.id            pm1.ns            pm1.styles        pm1.visibility


# cycle through each Australian structure
for structure in fldr_australia:
    # get namefield for class extraction,
    # ie "(0) Acraman, " => class 0or1
    namefield = structure.name or "(6) Error"
    pms = list(structure.features())    # get placemarks for the structure

    pm_icon, pm_poly = "", ""
    # check placemark is icon or polygon
    for pm in pms:
        if pm.